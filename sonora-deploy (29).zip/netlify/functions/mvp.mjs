// Proxy HLS cover animasi Apple (cadangan kalau browser diblokir CORS)
const OK = /(^|\.)(mzstatic\.com|apple\.com|aaplimg\.com|itunes\.apple\.com)$/i;
const cors = { "access-control-allow-origin": "*", "cache-control": "public, max-age=86400, s-maxage=604800" };

export default async (req) => {
  const u = new URL(req.url);
  let target;
  try { target = new URL(u.searchParams.get("u") || ""); } catch (e) { return new Response("bad", { status: 400 }); }
  if (target.protocol !== "https:" || !OK.test(target.hostname)) return new Response("forbidden", { status: 403 });
  try {
    const r = await fetch(target, { headers: { "user-agent": "Mozilla/5.0" }, signal: AbortSignal.timeout(20000) });
    if (!r.ok) return new Response("upstream " + r.status, { status: 502 });
    const ct = r.headers.get("content-type") || "";
    if (/mpegurl/i.test(ct) || /\.m3u8(\?|$)/i.test(target.pathname + target.search)) {
      const txt = await r.text();
      const px = (x) => "/api/mvp?u=" + encodeURIComponent(new URL(x, target).toString());
      const out = txt
        .split("\n")
        .map((l) => {
          const t = l.trim();
          if (!t) return l;
          if (t.startsWith("#")) return l.replace(/URI="([^"]+)"/g, (m, p) => 'URI="' + px(p) + '"');
          return px(t);
        })
        .join("\n");
      return new Response(out, { headers: { ...cors, "content-type": "application/vnd.apple.mpegurl" } });
    }
    return new Response(r.body, { headers: { ...cors, "content-type": ct || "application/octet-stream" } });
  } catch (e) {
    return new Response("fail", { status: 502 });
  }
};

export const config = { path: "/api/mvp" };
