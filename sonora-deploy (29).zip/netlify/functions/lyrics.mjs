import { getStore } from "@netlify/blobs";

// Lirik hanya diambil dari penyedia berlisensi (Musixmatch). Isi MUSIXMATCH_KEY di
// Netlify -> Environment variables. Tanpa kunci, fungsi ini mengembalikan 503 dan
// Sonora menampilkan "Lirik lagu ini belum tersedia".
const json = (o, status = 200, extra = {}) =>
  new Response(JSON.stringify(o), {
    status,
    headers: { "content-type": "application/json", ...extra },
  });

const norm = (s) =>
  String(s).toLowerCase().normalize("NFKD").replace(/[^\p{L}\p{N}]+/gu, " ").trim().slice(0, 160);

export default async (req) => {
  const u = new URL(req.url);
  const t = (u.searchParams.get("t") || "").slice(0, 100);
  const a = (u.searchParams.get("a") || "").slice(0, 80);
  if (!t) return json({ error: "query" }, 400);

  const apiKey = process.env.MUSIXMATCH_KEY;
  if (!apiKey) return json({ error: "no-key" }, 503);

  const store = getStore("lyrics-cache");
  const key = encodeURIComponent(norm(t + " " + a));
  try {
    const hit = await store.get(key, { type: "json" });
    if (hit && Array.isArray(hit.lines)) return json(hit, 200, { "cache-control": "public, max-age=86400" });
  } catch (_) {}

  const url =
    "https://api.musixmatch.com/ws/1.1/matcher.lyrics.get?format=json&q_track=" +
    encodeURIComponent(t) + "&q_artist=" + encodeURIComponent(a) +
    "&apikey=" + encodeURIComponent(apiKey);
  const r = await fetch(url);
  if (!r.ok) return json({ error: "provider" }, 502);
  const d = await r.json();
  const body = d && d.message && d.message.body && d.message.body.lyrics && d.message.body.lyrics.lyrics_body;
  if (!body) return json({ error: "not-found" }, 404);

  // Buang catatan hak cipta bawaan penyedia, sisakan baris lirik apa adanya.
  const lines = String(body)
    .split(/\r?\n/)
    .map((x) => x.trim())
    .filter((x) => x && !/^\*{3,}/.test(x) && !/^\(\d{6,}\)$/.test(x))
    .slice(0, 300);
  if (!lines.length) return json({ error: "not-found" }, 404);

  const out = { lines };
  try { await store.setJSON(key, out); } catch (_) {}
  return json(out, 200, { "cache-control": "public, max-age=86400" });
};

export const config = { path: "/api/lyrics" };
