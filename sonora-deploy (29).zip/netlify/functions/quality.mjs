import { getStore } from "@netlify/blobs";
import { createSign } from "node:crypto";

const json = (o, status = 200, extra = {}) =>
  new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", ...extra } });
const norm = (s) => String(s).toLowerCase().normalize("NFKD").replace(/[^\p{L}\p{N}]+/gu, "").slice(0, 120);
const b64 = (b) => Buffer.from(b).toString("base64url");

// Token pengembang Apple Music (MusicKit). Isi APPLE_TEAM_ID, APPLE_KEY_ID, APPLE_PRIVATE_KEY di Netlify.
let cached = null;
function token() {
  if (process.env.APPLE_MUSIC_TOKEN) return process.env.APPLE_MUSIC_TOKEN;
  const { APPLE_TEAM_ID: iss, APPLE_KEY_ID: kid, APPLE_PRIVATE_KEY: pk } = process.env;
  if (!iss || !kid || !pk) return null;
  const now = Math.floor(Date.now() / 1000);
  if (cached && cached.exp - now > 3600) return cached.t;
  const head = b64(JSON.stringify({ alg: "ES256", kid }));
  const exp = now + 60 * 60 * 24 * 30;
  const body = b64(JSON.stringify({ iss, iat: now, exp }));
  const sig = createSign("SHA256").update(head + "." + body).sign({ key: pk.replace(/\\n/g, "\n"), dsaEncoding: "ieee-p1363" });
  cached = { t: head + "." + body + "." + b64(sig), exp };
  return cached.t;
}

export default async (req) => {
  const u = new URL(req.url);
  const al = (u.searchParams.get("al") || "").slice(0, 100);
  const ar = (u.searchParams.get("a") || "").slice(0, 80);
  if (!al) return json({ error: "query" }, 400);
  const store = getStore("quality");
  const key = norm(al + ar);
  try {
    const hit = await store.get(key, { type: "json" });
    if (hit && Array.isArray(hit.traits)) return json(hit, 200, { "cache-control": "public, max-age=86400" });
  } catch (_) {}
  const tk = token();
  if (!tk) return json({ error: "no-token" }, 503);
  const r = await fetch(
    "https://api.music.apple.com/v1/catalog/us/search?types=albums&limit=6&term=" + encodeURIComponent(al + " " + ar),
    { headers: { Authorization: "Bearer " + tk } }
  );
  if (!r.ok) return json({ error: "apple" }, 502);
  const d = await r.json();
  const list = (d.results && d.results.albums && d.results.albums.data) || [];
  const m =
    list.find((x) => norm(x.attributes.name).startsWith(norm(al).slice(0, 12)) && norm(x.attributes.artistName).includes(norm(ar).slice(0, 5))) ||
    list.find((x) => norm(x.attributes.name).startsWith(norm(al).slice(0, 12)));
  const out = { traits: m ? (m.attributes.audioTraits || []).filter((t) => ["atmos", "hi-res-lossless", "lossless", "spatial"].includes(t)) : [], found: !!m };
  try { await store.setJSON(key, out); } catch (_) {}
  return json(out, 200, { "cache-control": "public, max-age=86400" });
};

export const config = { path: "/api/quality" };
