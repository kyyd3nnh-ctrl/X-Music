import { getStore } from "@netlify/blobs";

const json = (o, status = 200, extra = {}) =>
  new Response(JSON.stringify(o), {
    status,
    headers: { "content-type": "application/json", ...extra },
  });

const norm = (s) =>
  String(s).toLowerCase().normalize("NFKD").replace(/[^\p{L}\p{N}]+/gu, " ").trim().slice(0, 160);

const PIPED = ["https://pipedapi.kavin.rocks", "https://pipedapi.adminforge.de", "https://api.piped.private.coffee"];
const INVID = ["https://yewtu.be", "https://inv.nadeko.net"];
async function getJ(u) {
  try {
    const r = await fetch(u, { signal: AbortSignal.timeout(5000) });
    return r.ok ? await r.json() : null;
  } catch (_) { return null; }
}
const YBAD = /\b(live|remix|cover|sped ?up|slowed|reverb|karaoke|instrumental|nightcore|8d|reaction|tutorial|mashup|acoustic|piano|tiktok|dance practice|fancam|teaser|behind|making|shorts)\b/i;
const ynm = (x) => String(x || "").toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^\p{L}\p{N}]+/gu, " ").trim();
const ycl = (x) => String(x || "").replace(/\(.*?\)|\[.*?\]/g, " ").replace(/\s-\s.*$/, " ").replace(/\s+/g, " ").trim();
function yScore(c, t, a, d) {
  const nt = ynm(c.title), nc = ynm(c.ch), tt = ynm(ycl(t)), aa = ynm(String(a).split(/ & |, | feat\.? | x /i)[0]);
  let s = 0;
  if (tt && nt.includes(tt)) s += 5; else s -= 7;
  if (aa && (nt.includes(aa) || nc.includes(aa))) s += 3; else s -= 6;
  if (/ topic$/.test(nc)) s += 6;
  if (/\bofficial\b/.test(nt)) s += 1;
  if (/\baudio\b/.test(nt)) s += 1;
  if (d && c.dur) { const df = Math.abs(c.dur - d); s += df <= 2 ? 7 : df <= 5 ? 4 : df <= 10 ? 1 : df <= 25 ? -3 : -8; }
  if (YBAD.test(c.title) && !YBAD.test(t)) s -= 8;
  for (const r of [/japan|\bjp\b|日本/i, /\bkor|korean|한국/i, /\beng|english\b/i]) { const w = r.test(t), h = r.test(c.title + " " + (c.ch || "")); if (w && h) s += 4; else if (h && !w) s -= 5; else if (w && !h) s -= 2; }
  return s;
}
const YLANG = /\b(cover|covers|tribute|parody|karaoke|versi[oó]n|espa[nñ]ol|spanish|portugu[eê]s|portuguese|arabic|turkish|t[uü]rk[cç]e|hindi|indonesia|bahasa|thai|vietnam|french|german|italian|russian|japanese ver|korean ver|chinese|mandarin|instrumental|lofi|lo-fi|nightcore|8d|bass boosted|reaction|piano|guitar|acoustic|live)\b/i;
function yPick(l, t, a, d) {
  const aa = ynm(String(a).split(/ & |, | feat\.? | x /i)[0]), ok = [], rest = [];
  for (const c of l) {
    if (!/^[\w-]{11}$/.test(c.id || "")) continue;
    let x = yScore(c, t, a, d); const nc = ynm(c.ch);
    if (YLANG.test(c.title) && !YLANG.test(t)) x -= 12;
    if (d && c.dur && Math.abs(c.dur - d) > 12) x -= 10;
    const own = / topic$/.test(nc) || /vevo$/.test(nc) || (aa && nc.includes(aa)) || /\bofficial\b/.test(nc);
    (own ? ok : rest).push([x, c.id]);
  }
  const pick = (arr) => arr.sort((p, q) => q[0] - p[0])[0];
  const o = pick(ok); if (o && o[0] >= 2) return o[1];
  const r = pick(rest); if (r && r[0] >= 6) return r[1];
  if (o && o[0] >= -4) return o[1];
  const f = pick(ok.concat(rest).filter((x) => x[0] >= -6)); return f ? f[1] : null;
}
async function keyless(t, a, d) {
  const e = encodeURIComponent(t + " " + a);
  const jobs = [
    ...PIPED.map((b) => getJ(b + "/search?filter=music_songs&q=" + e).then((r) => {
      const l = r && (r.items || []).map((x) => ({ id: ((x.url || "").match(/v=([\w-]{11})/) || [])[1], title: x.title, ch: x.uploaderName, dur: x.duration })).filter((x) => x.id);
      return l && l.length ? l : null;
    })),
    ...INVID.map((b) => getJ(b + "/api/v1/search?type=video&q=" + e + "%20audio").then((r) => {
      const l = Array.isArray(r) && r.map((x) => ({ id: x.videoId, title: x.title, ch: x.author, dur: x.lengthSeconds })).filter((x) => /^[\w-]{11}$/.test(x.id || ""));
      return l && l.length ? l : null;
    })),
  ];
  const l = await new Promise((res) => {
    let n = jobs.length;
    jobs.forEach((j) => j.then((v) => { if (v) res(v); else if (--n === 0) res(null); }).catch(() => { if (--n === 0) res(null); }));
  });
  return l ? yPick(l, t, a, d) : null;
}

export default async (req) => {
  const u = new URL(req.url);
  const t = (u.searchParams.get("t") || "").slice(0, 100);
  const a = (u.searchParams.get("a") || "").slice(0, 80);
  const store = getStore("yt-ids");

  // Mode video klip: /api/yt?mv=1&a=Nama+Artis -> daftar video resmi, disimpan untuk semua pengguna.
  if (u.searchParams.get("mv")) {
    if (!a) return json({ error: "query" }, 400);
    const mkey = "mv-" + encodeURIComponent(norm(a));
    try {
      const hit = await store.get(mkey, { type: "json" });
      if (hit && Array.isArray(hit.items)) return json(hit, 200, { "cache-control": "public, max-age=86400" });
    } catch (_) {}
    const k = process.env.YT_API_KEY;
    if (!k) return json({ error: "no-key" }, 503);
    const r = await fetch(
      "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoCategoryId=10&videoEmbeddable=true&maxResults=8&q=" +
        encodeURIComponent(a + " official music video") + "&key=" + encodeURIComponent(k)
    );
    if (!r.ok) return json({ error: "youtube" }, r.status === 403 ? 429 : 502);
    const d = await r.json();
    const items = (d.items || [])
      .filter((x) => x.id && /^[\w-]{11}$/.test(x.id.videoId || ""))
      .map((x) => ({ id: x.id.videoId, t: String((x.snippet && x.snippet.title) || "").slice(0, 100) }));
    if (!items.length) return json({ error: "not-found" }, 404);
    const out = { items };
    try { await store.setJSON(mkey, out); } catch (_) {}
    return json(out, 200, { "cache-control": "public, max-age=86400" });
  }

  if (!t) return json({ error: "query" }, 400);
  const OVR = { "aespa|kiss n tell": "eSYMynGR0-M", "dua lipa|levitating": "ovG2QwiObhk" };
  { const na = norm(a).replace(/ /g, ""), nt = norm(ycl(t)).replace(/ /g, ""); for (const k in OVR) { const [ka, kt] = k.split("|"); if (na.includes(ka.replace(/ /g, "")) && nt === kt.replace(/ /g, "")) return json({ id: OVR[k] }, 200, { "cache-control": "no-store" }); } }
  const d0 = parseInt(u.searchParams.get("d") || "0", 10) || 0;
  const key = "v2-" + encodeURIComponent(norm(t + " " + a));

  // 1) Jawaban tersimpan: tidak memakai kuota YouTube.
  try {
    const hit = await store.get(key, { type: "json" });
    if (hit && /^[\w-]{11}$/.test(hit.id || "")) {
      return json(hit, 200, { "cache-control": "public, max-age=86400" });
    }
  } catch (_) {}

  // 2) Belum ada: cari sekali ke YouTube lalu simpan untuk semua pengguna.
  const apiKey = process.env.YT_API_KEY;
  if (!apiKey) {
    const id2 = await keyless(t, a, d0);
    if (!id2) return json({ error: "no-key" }, 503);
    try { await store.setJSON(key, { id: id2 }); } catch (_) {}
    return json({ id: id2 }, 200, { "cache-control": "public, max-age=86400" });
  }

  const r = await fetch(
    "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoEmbeddable=true&maxResults=10&q=" +
      encodeURIComponent(`${t} ${a} audio`) + "&key=" + encodeURIComponent(apiKey)
  );
  if (!r.ok) return json({ error: "youtube" }, r.status === 403 ? 429 : 502);
  const d = await r.json();
  const its = (d.items || []).filter((x) => x.id && x.id.videoId);
  if (!its.length) return json({ error: "not-found" }, 404);
  const du = {};
  try {
    const rv = await fetch("https://www.googleapis.com/youtube/v3/videos?part=contentDetails&id=" + its.map((x) => x.id.videoId).join(",") + "&key=" + encodeURIComponent(apiKey));
    const dv = await rv.json();
    for (const x of dv.items || []) { const m = (x.contentDetails.duration || "").match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/) || []; du[x.id] = (+m[1] || 0) * 3600 + (+m[2] || 0) * 60 + (+m[3] || 0); }
  } catch (_) {}
  const id = yPick(its.map((x) => ({ id: x.id.videoId, title: x.snippet.title, ch: x.snippet.channelTitle, dur: du[x.id.videoId] })), t, a, d0) || its[0].id.videoId;

  const out = { id };
  try { await store.setJSON(key, out); } catch (_) {}
  return json(out, 200, { "cache-control": "public, max-age=86400" });
};

export const config = { path: "/api/yt" };
