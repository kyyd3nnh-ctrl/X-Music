// Cover animasi Apple Music (HLS .m3u8) lewat API artwork.m8tec.top
const HOST = "https://artwork.m8tec.top";
const json = (o, extra = {}) =>
  new Response(JSON.stringify(o), {
    headers: { "content-type": "application/json", "access-control-allow-origin": "*", ...extra },
  });

const cleanAl = (s) =>
  s
    .replace(/\s*[\(\[][^)\]]*(deluxe|edition|version|remaster|expanded|bonus|special|anniversary|complete)[^)\]]*[\)\]]/gi, "")
    .replace(/\s+-\s+(single|ep)$/i, "")
    .trim();
const firstAr = (s) => s.split(/\s*(?:,|&|;|\/)\s*|\s+(?:feat\.?|ft\.?|x|and|with)\s+/i)[0].trim();

function walk(x, k, out) {
  if (typeof x === "string") {
    if (/\.m3u8(\?|$)/i.test(x)) out.push([k, x]);
  } else if (x && typeof x === "object") for (const kk in x) walk(x[kk], kk, out);
}

export default async (req) => {
  const u = new URL(req.url);
  const a = (u.searchParams.get("a") || "").slice(0, 120);
  const al = (u.searchParams.get("al") || "").slice(0, 160);
  const t = (u.searchParams.get("t") || "").slice(0, 160);
  if (!a || !al) return json({ url: null });
  const fa = firstAr(a) || a,
    cal = cleanAl(al) || al;
  const seen = new Set(),
    list = [];
  for (const v of [[a, al, t], [a, al, ""], [fa, cal, t], [fa, cal, ""]]) {
    const k = v.join("|");
    if (!seen.has(k)) {
      seen.add(k);
      list.push(v);
    }
  }
  let failed = false;
  const res = await Promise.all(
    list.map(async ([ar, alb, ti]) => {
      try {
        const q = new URLSearchParams({ artist: ar, album: alb });
        if (ti) q.set("title", ti);
        const r = await fetch(HOST + "/api/v1/artwork/search?" + q, {
          headers: { accept: "application/json", "user-agent": "XMusic/1.0" },
          signal: AbortSignal.timeout(7000),
        });
        if (r.status === 404) return null;
        if (!r.ok) {
          failed = true;
          return null;
        }
        const d = await r.json();
        const found = [];
        walk(d, "", found);
        return found.length ? found : null;
      } catch (e) {
        failed = true;
        return null;
      }
    })
  );
  let found = res.find(Boolean);
  if (!found) {
    // cadangan: cari album di Apple Music (iTunes) lalu minta artwork lewat URL resminya
    try {
      const it = await fetch("https://itunes.apple.com/search?" + new URLSearchParams({ term: fa + " " + cal, entity: "album", limit: "4" }), { signal: AbortSignal.timeout(6000) });
      if (it.ok) {
        const d = await it.json();
        const nz = (x) => String(x || "").toLowerCase().replace(/[^a-z0-9]+/g, "");
        const cands = (d.results || []).filter((r) => r.collectionViewUrl && nz(r.collectionName).includes(nz(cal).slice(0, 12)));
        for (const c of cands.slice(0, 2)) {
          try {
            const r = await fetch(HOST + "/api/v1/artwork/url?" + new URLSearchParams({ url: c.collectionViewUrl }), { headers: { accept: "application/json", "user-agent": "XMusic/1.0" }, signal: AbortSignal.timeout(7000) });
            if (r.status === 404) continue;
            if (!r.ok) { failed = true; continue; }
            const f = [];
            walk(await r.json(), "", f);
            if (f.length) { found = f; break; }
          } catch (e) { failed = true; }
        }
      }
    } catch (e) {}
  }
  if (found) {
    const sq = found.find(([k, v]) => /square/i.test(k + v)) || found.find(([k, v]) => !/tall|portrait/i.test(k + v)) || found[0];
    const tall = found.find(([k, v]) => /tall|portrait/i.test(k + v));
    return json({ url: sq[1], tall: tall ? tall[1] : null }, { "cache-control": "public, max-age=86400, s-maxage=604800" });
  }
  if (failed) return json({ url: null, err: 1 }, { "cache-control": "no-store" });
  return json({ url: null }, { "cache-control": "public, max-age=3600" });
};

export const config = { path: "/api/motion" };
