# X Music - Panduan Singkat

## A. Kunci API (Netlify -> Site configuration -> Environment variables)
Masukkan di Netlify, JANGAN di chat/kode:
- YT_API_KEY      : YouTube Data API v3 (Google Cloud Console -> Enable API -> Credentials -> API key). Membuat pencarian lagu stabil.
- MUSIXMATCH_KEY  : developer.musixmatch.com -> API key. Membuat lirik lebih lengkap dan akurat.
- (opsional) Apple MusicKit: untuk label Hi-Res/Lossless asli (quality.mjs).
Setelah menambah, jalankan Deploys -> Trigger deploy.

## B. Aplikasi Android (musik tetap jalan di latar belakang)
1. Upload folder ini ke repo GitHub.
2. Edit native/capacitor.config.json: ganti server.url dengan alamat Netlify-mu.
3. GitHub -> Actions -> "Build Android APK" -> Run workflow. Unduh app-debug.apk dari Artifacts.
Catatan: belum diuji dari sisi saya. iPhone butuh Mac + akun Apple Developer, jadi pakai "Add to Home Screen" dulu.

## C. Soal "audio resmi dari artis"
Aplikasi memilih video dari kanal "Topic"/resmi artis dan menolak live, remix, cover, instrumental.
Audio berlisensi langsung dari label hanya bisa lewat layanan resmi (Apple Music/Spotify) dengan langganan.

## D. Discord "Listening to" (khusus PC)
1. https://discord.com/developers/applications -> New Application -> salin Application ID.
2. Di PC: install Node.js, buka folder discord-presence, jalankan:
   set DISCORD_CLIENT_ID=ID_KAMU   (Windows)   /   export DISCORD_CLIENT_ID=ID_KAMU (Mac/Linux)
   npm install && npm start
3. Biarkan Discord desktop terbuka, lalu putar lagu di web. Status "Listening to" muncul otomatis.
Website tidak bisa mengakses Discord langsung, jadi helper kecil ini diperlukan.
