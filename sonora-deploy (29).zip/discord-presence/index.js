// Helper Discord "Listening to" untuk X Music (jalankan di PC yang sama dengan Discord).
// 1) Buat aplikasi di https://discord.com/developers/applications -> salin Application ID.
// 2) set DISCORD_CLIENT_ID=ID_KAMU lalu: npm install && npm start
const http = require("http");
const RPC = require("discord-rpc");
const id = process.env.DISCORD_CLIENT_ID;
if (!id) { console.error("Isi DISCORD_CLIENT_ID dulu."); process.exit(1); }
const rpc = new RPC.Client({ transport: "ipc" });
let ready = false;
rpc.on("ready", () => { ready = true; console.log("Terhubung ke Discord."); });
rpc.login({ clientId: id }).catch((e) => console.error("Gagal login Discord:", e.message));
http.createServer((req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Private-Network", "true");
  res.setHeader("Access-Control-Allow-Headers", "*");
  if (req.method === "OPTIONS") { res.writeHead(204); return res.end(); }
  let b = ""; req.on("data", (c) => (b += c)); req.on("end", () => {
    res.end("ok");
    if (!ready) return;
    try {
      const d = JSON.parse(b);
      if (!d.on) return rpc.clearActivity();
      const start = Date.now() - (d.pos || 0) * 1000;
      rpc.setActivity({
        type: 2, details: String(d.t).slice(0, 120), state: String(d.ar).slice(0, 120),
        largeImageKey: /^https:/.test(d.art) ? d.art : undefined, largeImageText: String(d.al || "X Music").slice(0, 120),
        startTimestamp: start, endTimestamp: d.dur ? start + d.dur * 1000 : undefined, instance: false,
      }).catch(() => {});
    } catch (_) {}
  });
}).listen(3737, "127.0.0.1", () => console.log("Helper aktif di http://127.0.0.1:3737"));
